create function st_asraster(geom geometry, ref raster, pixeltype text, value double precision DEFAULT 1, nodataval double precision DEFAULT 0, touched boolean DEFAULT false)
  returns raster
immutable
parallel safe
language sql
as $$
SELECT  public.ST_AsRaster($1, $2, ARRAY[$3]::text[], ARRAY[$4]::double precision[], ARRAY[$5]::double precision[], $6)
$$;

comment on function st_asraster(geometry, raster, text, double precision, double precision, boolean)
is 'args: geom, ref, pixeltype, value=1, nodataval=0, touched=false - Converts a PostGIS geometry to a PostGIS raster.';

alter function st_asraster(geometry, raster, text, double precision, double precision, boolean)
  owner to pp;

