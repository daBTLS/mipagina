create function st_pixelofvalue(rast raster, search double precision[], exclude_nodata_value boolean DEFAULT true, OUT val double precision, OUT x integer, OUT y integer)
  returns SETOF record
immutable
strict
parallel safe
language sql
as $$
SELECT val, x, y FROM public.ST_PixelOfValue($1, 1, $2, $3)
$$;

comment on function st_pixelofvalue(raster, double precision [], boolean, out double precision, out integer,
                                                                          out integer)
is 'args: rast, search, exclude_nodata_value=true - Get the columnx, rowy coordinates of the pixel whose value equals the search value.';

alter function st_pixelofvalue(raster, double precision [], boolean, out double precision, out integer, out integer)
  owner to pp;

